const sayHi = (name) => {
  console.log(`Hello there ${name}`);
};
const sayHi2 = (name) => {
  console.log(`Hello there ${name}`);
};
const sayHi3 = (name) => {
  console.log(`Hello there ${name}`);
};
const sayHi4 = (name) => {
  console.log(`Hello there ${name}`);
};
// export default
module.exports = { sayHi, sayHi2, sayHi3};

// Import the built in module: http
const http = require("http");
const server = http.createServer();
server.listen(3000);

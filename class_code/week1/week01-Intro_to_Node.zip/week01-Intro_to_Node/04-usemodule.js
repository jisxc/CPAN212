const {sayHi, sayHi2, sayHi3} = require("../week01/02-modulesv1")
const mod2 = require("../week01/03-modulesv2")

// console.log(mod1)
// console.log(mod1.sayHi())
// console.log(mod2.items)
// console.log(mod2.singlePerson)
sayHi2("Harman")
console.log()